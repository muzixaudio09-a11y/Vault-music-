package com.example.util

import java.net.URI

sealed interface UrlDecision {
    data object AllowInWebView : UrlDecision
    data class OpenExternally(val url: String) : UrlDecision
    data object Block : UrlDecision
}

object UrlPolicy {
    const val PRIMARY_URL = "https://moonlit-trifle-74edc5.netlify.app"
    const val PRIMARY_HOST = "moonlit-trifle-74edc5.netlify.app"

    private val externalActionSchemes = setOf("mailto", "tel")

    fun evaluateNavigation(rawUrl: String?, isMainFrame: Boolean): UrlDecision {
        if (rawUrl.isNullOrBlank()) return UrlDecision.Block

        val trimmed = rawUrl.trim()
        val uri = runCatching { URI(trimmed) }.getOrNull() ?: return UrlDecision.Block
        val scheme = uri.scheme?.lowercase() ?: return UrlDecision.Block
        val host = uri.host?.lowercase().orEmpty()

        return when {
            scheme == "https" && isPrimaryHost(host) -> UrlDecision.AllowInWebView
            scheme in setOf("http", "https") -> {
                if (isMainFrame) {
                    UrlDecision.OpenExternally(trimmed)
                } else {
                    if (scheme == "https") UrlDecision.AllowInWebView else UrlDecision.Block
                }
            }
            scheme in externalActionSchemes && isMainFrame -> UrlDecision.OpenExternally(trimmed)
            else -> UrlDecision.Block
        }
    }

    fun isSafeInitialUrl(rawUrl: String): Boolean {
        val uri = runCatching { URI(rawUrl.trim()) }.getOrNull() ?: return false
        return uri.scheme?.equals("https", ignoreCase = true) == true &&
            isPrimaryHost(uri.host?.lowercase().orEmpty())
    }

    fun isHttpsUrl(rawUrl: String?): Boolean {
        if (rawUrl.isNullOrBlank()) return false
        val uri = runCatching { URI(rawUrl.trim()) }.getOrNull() ?: return false
        return uri.scheme?.equals("https", ignoreCase = true) == true
    }

    fun displayHost(rawUrl: String?): String {
        if (rawUrl.isNullOrBlank()) return PRIMARY_HOST
        val uri = runCatching { URI(rawUrl.trim()) }.getOrNull()
        return uri?.host?.takeIf { it.isNotBlank() } ?: PRIMARY_HOST
    }

    private fun isPrimaryHost(host: String): Boolean {
        return host == PRIMARY_HOST || host == "www.$PRIMARY_HOST"
    }
}
