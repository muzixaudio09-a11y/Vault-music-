package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.VaultPlayScreen
import com.example.ui.VaultPlayViewModel
import com.example.ui.theme.VaultPlayTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            VaultPlayTheme {
                val vaultPlayViewModel: VaultPlayViewModel = viewModel(
                    factory = VaultPlayViewModel.Factory(application)
                )
                VaultPlayScreen(viewModel = vaultPlayViewModel)
            }
        }
    }
}
