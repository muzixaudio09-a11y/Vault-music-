package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val VaultPlayColorScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = PitchBlack,
    primaryContainer = EmeraldGlowContainer,
    onPrimaryContainer = NeonGreen,
    secondary = EmeraldGreen,
    onSecondary = PitchBlack,
    secondaryContainer = EmeraldGlowContainer,
    onSecondaryContainer = EmeraldGreen,
    background = PitchBlack,
    onBackground = PureWhite,
    surface = FrostedDarkGlass,
    onSurface = PureWhite,
    surfaceVariant = ElevatedGlass,
    onSurfaceVariant = MutedMintText,
    surfaceContainerLowest = PitchBlack,
    surfaceContainerLow = FrostedDarkGlass,
    surfaceContainer = FrostedDarkGlass,
    surfaceContainerHigh = ElevatedGlass,
    outline = GlassBorder,
    outlineVariant = GlassBorder,
    error = ErrorCoral,
    errorContainer = ErrorGlass
)

val VaultPlayShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun VaultPlayTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VaultPlayColorScheme,
        typography = VaultPlayTypography,
        shapes = VaultPlayShapes,
        content = content
    )
}
