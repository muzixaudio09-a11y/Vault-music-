package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// VaultPlay Exact Palette
val PitchBlack = Color(0xFF040604)
val FrostedDarkGlass = Color(0xFF080D0A)
val ElevatedGlass = Color(0xFF0E1611)
val NeonGreen = Color(0xFF00FF66)
val EmeraldGreen = Color(0xFF10B981)
val EmeraldGlowContainer = Color(0xFF0A291A)
val PureWhite = Color(0xFFF5FFF8)
val MutedMintText = Color(0xFF8CA396)
val GlassBorder = Color(0xFF17291E)
val ErrorCoral = Color(0xFFFF6B6B)
val ErrorGlass = Color(0xFF220D0E)
