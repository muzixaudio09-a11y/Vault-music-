package com.example.ui.components

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.VaultWebCommand
import com.example.util.UrlDecision
import com.example.util.UrlPolicy
import kotlinx.coroutines.flow.SharedFlow

private const val VAULT_PITCH_BLACK_INT = 0xFF040604.toInt()

/**
 * Surgical runtime DOM/CSS enhancements applied inside VaultPlayWebView:
 * 1. Hides any "Powered by Netlify" badge, watermark, iframe, or preview drawer widget.
 * 2. Compacts the docked mini-player bar above the bottom navigation bar, hides any visible
 *    "Queue" label and drag-handle pill, and binds taps on the song title/info to open Queue.
 * 3. Shifts only the innermost active Play-screen stack (artwork, track row, scrubber,
 *    transport controls) cleanly downward above the bottom navigation bar.
 */
private const val VAULTPLAY_DOM_ENHANCEMENTS_JS = """
(function() {
  try {
    if (!document.getElementById('vaultplay-native-polish-style')) {
      var style = document.createElement('style');
      style.id = 'vaultplay-native-polish-style';
      style.textContent =
        '[data-netlify-badge], #netlify-badge, .netlify-badge, #netlify-drawer, [data-netlify-drawer], ' +
        'iframe[src*="netlify" i], iframe[title*="netlify" i], a[href*="netlify.com"], ' +
        'a[href*="netlify.app"]:not([href*="moonlit-trifle-74edc5"]), img[alt*="Netlify" i], ' +
        '[aria-label*="Powered by Netlify" i] { ' +
        '  display: none !important; visibility: hidden !important; opacity: 0 !important; pointer-events: none !important; ' +
        '} ' +
        '.vp-slim-miniplayer { ' +
        '  padding-top: 6px !important; padding-bottom: 6px !important; min-height: 0 !important; ' +
        '} ' +
        '.vp-play-stack-shifted { ' +
        '  display: flex !important; flex-direction: column !important; justify-content: flex-end !important; padding-bottom: 14px !important; ' +
        '} ' +
        '.vp-artist-trigger { cursor: pointer !important; } ' +
        '#vp-song-info-backdrop { ' +
        '  position: fixed; inset: 0; z-index: 99999; background: rgba(4, 6, 4, 0.82); ' +
        '  backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); ' +
        '  display: flex; align-items: flex-end; justify-content: center; padding: 16px; ' +
        '} ' +
        '#vp-song-info-card { ' +
        '  width: 100%; max-width: 460px; max-height: 78vh; overflow-y: auto; ' +
        '  background: rgba(8, 13, 10, 0.96); border: 1px solid rgba(16, 185, 129, 0.30); ' +
        '  border-radius: 22px; padding: 18px 20px 22px; color: #F5FFF8; ' +
        '  box-shadow: 0 16px 48px rgba(0, 0, 0, 0.72); font-family: inherit; ' +
        '}';
      (document.head || document.documentElement).appendChild(style);
    }

    var hideEl = function(el) {
      if (!el || !el.style) return;
      el.style.setProperty('display', 'none', 'important');
      el.style.setProperty('visibility', 'hidden', 'important');
      el.style.setProperty('opacity', '0', 'important');
      el.style.setProperty('pointer-events', 'none', 'important');
    };

    var hideNetlifyInRoot = function(root) {
      if (!root || !root.querySelectorAll) return;
      var els = root.querySelectorAll('*');
      for (var i = 0; i < els.length; i++) {
        var el = els[i];
        if (el.id === 'vp-song-info-backdrop' || (el.closest && el.closest('#vp-song-info-backdrop'))) continue;
        if (el.shadowRoot) {
          hideNetlifyInRoot(el.shadowRoot);
        }
        var tag = (el.tagName || '').toLowerCase();
        if (tag === 'html' || tag === 'body' || tag === 'main' || tag === 'nav' || tag === 'script' || tag === 'style') continue;
        if (el.id === 'root' || el.id === 'app') continue;

        var href = (el.getAttribute && el.getAttribute('href')) || '';
        var src = (el.getAttribute && el.getAttribute('src')) || '';
        var alt = (el.getAttribute && el.getAttribute('alt')) || '';
        var aria = (el.getAttribute && el.getAttribute('aria-label')) || '';
        var rawText = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
        var lowerText = rawText.toLowerCase();

        if (href.toLowerCase().indexOf('netlify.com') !== -1 ||
            alt.toLowerCase().indexOf('netlify') !== -1 ||
            aria.toLowerCase().indexOf('powered by netlify') !== -1 ||
            (tag === 'iframe' && src.toLowerCase().indexOf('netlify') !== -1)) {
          hideEl(el);
          continue;
        }

        if (lowerText.indexOf('powered by netlify') !== -1 && rawText.length <= 72) {
          var rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
          if (!rect || rect.height <= 110) {
            hideEl(el);
            var parent = el.parentElement;
            if (parent && parent.id !== 'root' && parent.id !== 'app' && (parent.tagName || '').toLowerCase() !== 'body') {
              var pText = (parent.innerText || parent.textContent || '').replace(/\s+/g, ' ').trim();
              var pRect = parent.getBoundingClientRect ? parent.getBoundingClientRect() : null;
              if (pText.length <= 72 && (!pRect || pRect.height <= 110)) {
                hideEl(parent);
              }
            }
          }
        }
      }
    };

    var findBottomNav = function() {
      var vh = window.innerHeight || 800;
      var candidates = document.querySelectorAll('nav, footer, div');
      var bestEl = null;
      var bestTop = vh - 64;
      for (var i = 0; i < candidates.length; i++) {
        var el = candidates[i];
        if (!el.getBoundingClientRect) continue;
        var rect = el.getBoundingClientRect();
        if (rect.height < 40 || rect.height > 110 || rect.bottom < vh - 24) continue;
        var txt = (el.innerText || '').toLowerCase();
        if (txt.indexOf('play') !== -1 && txt.indexOf('playlists') !== -1 &&
            txt.indexOf('library') !== -1 && txt.indexOf('community') !== -1) {
          bestEl = el;
          bestTop = rect.top;
        }
      }
      return { el: bestEl, top: bestTop };
    };

    var enhanceMiniPlayer = function(bottomNav) {
      var vw = window.innerWidth || 400;
      var navTop = bottomNav.top;
      var candidates = document.querySelectorAll('div, section, aside');
      for (var i = 0; i < candidates.length; i++) {
        var el = candidates[i];
        if (el === bottomNav.el || (bottomNav.el && el.contains(bottomNav.el))) continue;
        if (!el.getBoundingClientRect) continue;
        var rect = el.getBoundingClientRect();
        if (rect.height < 40 || rect.height > 135) continue;
        if (rect.width < vw * 0.78) continue;
        if (rect.bottom > navTop + 6 || rect.bottom < navTop - 40) continue;

        var stylePos = window.getComputedStyle ? window.getComputedStyle(el).position : '';
        var parentPos = (el.parentElement && window.getComputedStyle) ? window.getComputedStyle(el.parentElement).position : '';
        if (stylePos !== 'fixed' && stylePos !== 'sticky' && parentPos !== 'fixed' && parentPos !== 'sticky') {
          continue;
        }

        var btns = el.querySelectorAll('button');
        if (btns.length < 1 || btns.length > 5) continue;

        el.classList.add('vp-slim-miniplayer');

        var queueTrigger = el.querySelector('[aria-label*="queue" i]');
        var children = el.querySelectorAll('button, span, div, p, small');
        for (var j = 0; j < children.length; j++) {
          var child = children[j];
          var txt = (child.innerText || child.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
          if (txt === 'queue') {
            if (!queueTrigger) {
              queueTrigger = child.closest('button') || child;
            }
            hideEl(child);
          } else if (txt === '' && child.children.length === 0 && child.getBoundingClientRect) {
            var cr = child.getBoundingClientRect();
            if (cr.width >= 20 && cr.width <= 84 && cr.height >= 2 && cr.height <= 9) {
              hideEl(child);
            }
          }
        }

        if (queueTrigger && !el.dataset.vpQueueBound) {
          el.dataset.vpQueueBound = '1';
          el.addEventListener('click', function(ev) {
            var target = ev.target;
            if (!target) return;
            var clickedBtn = target.closest && target.closest('button');
            if (clickedBtn && clickedBtn !== queueTrigger && el.contains(clickedBtn)) {
              return;
            }
            if (typeof queueTrigger.click === 'function') {
              queueTrigger.click();
            }
          }, false);
        }
      }
    };

    var formatSecs = function(sec) {
      if (!isFinite(sec) || sec <= 0) return '';
      var m = Math.floor(sec / 60);
      var s = Math.floor(sec % 60);
      return m + ':' + (s < 10 ? '0' : '') + s;
    };

    var isExtraMetaSegment = function(seg) {
      var s = (seg || '').replace(/\u2026|\.\.\./g, '').trim().toLowerCase();
      if (!s) return true;
      if (s.indexOf('local recording') !== -1 || s.indexOf('local file') !== -1) return true;
      if (/^\d+(\.\d+)?x$/.test(s)) return true;
      if (/^\d+s\s*(fad|crossfad)/i.test(s)) return true;
      if (/^(mp3|wav|flac|m4a|aac|ogg|opus|webm)$/.test(s)) return true;
      if (/^\d+\s*kbps$/.test(s)) return true;
      return false;
    };

    var lookupStoredTrack = function(titleHint) {
      var result = {};
      try {
        var normTitle = (titleHint || '').trim().toLowerCase();
        for (var i = 0; i < localStorage.length; i++) {
          var raw = localStorage.getItem(localStorage.key(i));
          if (!raw || (raw[0] !== '{' && raw[0] !== '[')) continue;
          var parsed = JSON.parse(raw);
          var stack = Array.isArray(parsed) ? parsed.slice() : [parsed];
          while (stack.length > 0) {
            var item = stack.shift();
            if (!item || typeof item !== 'object') continue;
            if (Array.isArray(item)) {
              for (var k = 0; k < item.length; k++) stack.push(item[k]);
              continue;
            }
            var t = (item.title || item.name || item.trackTitle || '').toString().trim().toLowerCase();
            if (normTitle && t === normTitle) {
              return item;
            }
            for (var prop in item) {
              if (item[prop] && typeof item[prop] === 'object') {
                stack.push(item[prop]);
              }
            }
          }
        }
      } catch (_) {}
      return result;
    };

    var openSongInfoModal = function(info) {
      var existing = document.getElementById('vp-song-info-backdrop');
      if (existing && existing.parentElement) existing.parentElement.removeChild(existing);

      var backdrop = document.createElement('div');
      backdrop.id = 'vp-song-info-backdrop';
      backdrop.setAttribute('role', 'dialog');
      backdrop.setAttribute('aria-modal', 'true');

      var card = document.createElement('div');
      card.id = 'vp-song-info-card';

      var header = document.createElement('div');
      header.style.cssText = 'display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid rgba(16,185,129,0.22);';

      var hTitle = document.createElement('div');
      hTitle.textContent = 'Song Info';
      hTitle.style.cssText = 'font-size:17px;font-weight:700;color:#00FF66;letter-spacing:0.2px;';

      var closeBtn = document.createElement('button');
      closeBtn.type = 'button';
      closeBtn.textContent = '✕';
      closeBtn.setAttribute('aria-label', 'Close song info');
      closeBtn.style.cssText = 'background:rgba(16,185,129,0.14);color:#00FF66;border:1px solid rgba(16,185,129,0.35);border-radius:999px;width:32px;height:32px;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;';

      header.appendChild(hTitle);
      header.appendChild(closeBtn);
      card.appendChild(header);

      var addRow = function(label, val) {
        if (!val) return;
        var row = document.createElement('div');
        row.style.cssText = 'padding:8px 0;border-bottom:1px solid rgba(255,255,255,0.06);';
        var lbl = document.createElement('div');
        lbl.textContent = label;
        lbl.style.cssText = 'font-size:11px;text-transform:uppercase;letter-spacing:0.7px;color:#10B981;margin-bottom:2px;font-weight:600;';
        var v = document.createElement('div');
        v.textContent = val;
        v.style.cssText = 'font-size:14px;color:#F5FFF8;word-break:break-word;white-space:pre-wrap;';
        row.appendChild(lbl);
        row.appendChild(v);
        card.appendChild(row);
      };

      addRow('Title', info.title || 'Unknown Track');
      addRow('Artist', info.artist || 'Unknown Artist');
      addRow('Album / Format', info.albumFormat || 'Local Audio');
      addRow('Duration', info.duration || '—');
      addRow('File Path / Source', info.source || 'Local Storage');
      addRow('Play Count', info.playCount !== undefined && info.playCount !== null ? String(info.playCount) : '—');
      if (info.notes) {
        addRow('Lyrics / Notes', info.notes);
      }

      backdrop.appendChild(card);
      document.body.appendChild(backdrop);

      var closeModal = function() {
        if (backdrop.parentElement) backdrop.parentElement.removeChild(backdrop);
        document.removeEventListener('keydown', onKey);
      };
      var onKey = function(ev) {
        if (ev.key === 'Escape') closeModal();
      };
      closeBtn.addEventListener('click', closeModal);
      backdrop.addEventListener('click', function(ev) {
        if (ev.target === backdrop) closeModal();
      });
      document.addEventListener('keydown', onKey);
    };

    var gatherSongInfo = function(playBox, titleText, artistText, extraMetaText) {
      var ms = (navigator.mediaSession && navigator.mediaSession.metadata) ? navigator.mediaSession.metadata : null;
      var resolvedTitle = titleText || (ms && ms.title) || 'Unknown Track';
      var stored = lookupStoredTrack(resolvedTitle);
      var audioEl = document.querySelector('audio');

      var durationText = '';
      if (audioEl && isFinite(audioEl.duration) && audioEl.duration > 0) {
        durationText = formatSecs(audioEl.duration);
      } else if (stored.duration) {
        durationText = typeof stored.duration === 'number' ? formatSecs(stored.duration) : String(stored.duration);
      } else if (playBox) {
        var timeMatches = (playBox.innerText || '').match(/\b\d{1,2}:\d{2}\b/g);
        if (timeMatches && timeMatches.length >= 2) {
          durationText = timeMatches[timeMatches.length - 1];
        }
      }

      var albumParts = [];
      if (ms && ms.album) albumParts.push(ms.album);
      else if (stored.album) albumParts.push(stored.album);
      if (stored.format || stored.mimeType || stored.codec) {
        albumParts.push(stored.format || stored.mimeType || stored.codec);
      } else if (extraMetaText) {
        albumParts.push(extraMetaText);
      }

      var sourcePath = stored.filePath || stored.path || stored.fileName || stored.source ||
        (audioEl && audioEl.currentSrc && audioEl.currentSrc.indexOf('blob:') !== 0 ? audioEl.currentSrc : '') ||
        (extraMetaText && extraMetaText.toLowerCase().indexOf('local') !== -1 ? 'Local Recording (Device Storage)' : 'VaultPlay Offline Vault');

      var plays = stored.playCount !== undefined ? stored.playCount :
        (stored.plays !== undefined ? stored.plays : stored.count);

      var notes = stored.lyrics || stored.notes || stored.description || '';

      return {
        title: resolvedTitle,
        artist: artistText || (ms && ms.artist) || stored.artist || 'Unknown Artist',
        albumFormat: albumParts.join(' · '),
        duration: durationText,
        source: sourcePath,
        playCount: plays,
        notes: notes
      };
    };

    var enhancePlayScreenMetadata = function(playBox) {
      if (!playBox) return;

      var allTextEls = playBox.querySelectorAll('p, span, div, h1, h2, h3, h4, small');
      var metaEl = null;
      var metaRaw = '';

      for (var i = 0; i < allTextEls.length; i++) {
        var el = allTextEls[i];
        if (el.dataset && el.dataset.vpArtistClone === '1') continue;
        if (el.closest && el.closest('#vp-song-info-backdrop')) continue;
        if (el.querySelector && el.querySelector('h1, h2, h3, h4, button')) continue;
        if (el.children && el.children.length > 0) {
          var childHasMeta = false;
          for (var c = 0; c < el.children.length; c++) {
            var ct = (el.children[c].innerText || el.children[c].textContent || '').toLowerCase();
            if (ct.indexOf('local recording') !== -1 || /\b\d+(\.\d+)?x\b/.test(ct)) {
              childHasMeta = true;
              break;
            }
          }
          if (childHasMeta) continue;
        }

        var txt = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
        if (!txt || txt.length > 140) continue;

        var lower = txt.toLowerCase();
        var hasMetaMarker =
          lower.indexOf('local recording') !== -1 ||
          (/\b\d+(\.\d+)?x\b/.test(lower) && txt.indexOf('·') !== -1) ||
          (/\b\d+s\s*fad/i.test(lower));

        if (hasMetaMarker) {
          metaEl = el;
          metaRaw = txt;
          break;
        }
      }

      var titleGuess = '';
      var headings = playBox.querySelectorAll('h1, h2, h3, [class*="title" i], [class*="font-bold" i], [class*="font-semibold" i]');
      for (var h = 0; h < headings.length; h++) {
        var ht = (headings[h].innerText || '').replace(/\s+/g, ' ').trim();
        if (ht && ht !== metaRaw && ht.length <= 90 && ht.toLowerCase().indexOf('local recording') === -1) {
          titleGuess = ht;
          break;
        }
      }

      var artistTargetEl = null;
      var artistName = '';

      if (metaEl) {
        var parts = metaRaw.split('·').map(function(p) { return p.trim(); }).filter(Boolean);
        var nonMetaParts = parts.filter(function(p) { return !isExtraMetaSegment(p); });

        if (nonMetaParts.length > 0) {
          // Artist name and extra metadata share the same element; hide original safely and render clean artist trigger
          artistName = nonMetaParts.join(' · ');
          hideEl(metaEl);
          var existingClone = metaEl.parentElement && metaEl.parentElement.querySelector('[data-vp-artist-clone="1"]');
          if (!existingClone) {
            existingClone = document.createElement('span');
            existingClone.setAttribute('data-vp-artist-clone', '1');
            existingClone.className = (metaEl.className || '') + ' vp-artist-trigger';
            existingClone.style.cssText = 'display:inline-block;cursor:pointer;';
            metaEl.insertAdjacentElement('afterend', existingClone);
          }
          if (existingClone.textContent !== artistName) {
            existingClone.textContent = artistName;
          }
          artistTargetEl = existingClone;
        } else {
          // Pure metadata line beneath the artist line: hide only the metadata line
          hideEl(metaEl);
          var prev = metaEl.previousElementSibling;
          if (prev) {
            var prevTxt = (prev.innerText || prev.textContent || '').replace(/\s+/g, ' ').trim();
            if (prevTxt && prevTxt !== titleGuess) {
              artistTargetEl = prev;
              artistName = prevTxt;
            }
          }
        }
      }

      if (!artistTargetEl && titleGuess) {
        // Fallback: look for immediate sibling beneath title element
        for (var k = 0; k < headings.length; k++) {
          var hEl = headings[k];
          if ((hEl.innerText || '').replace(/\s+/g, ' ').trim() === titleGuess) {
            var sib = hEl.nextElementSibling;
            while (sib && sib.style && sib.style.display === 'none') {
              sib = sib.nextElementSibling;
            }
            if (sib) {
              var sibTxt = (sib.innerText || sib.textContent || '').replace(/\s+/g, ' ').trim();
              if (sibTxt && sibTxt.length <= 72 && !/\d+:\d+/.test(sibTxt)) {
                artistTargetEl = sib;
                artistName = sibTxt;
              }
            }
            break;
          }
        }
      }

      if (artistTargetEl) {
        artistTargetEl.classList.add('vp-artist-trigger');
        artistTargetEl.dataset.vpTitleHint = titleGuess;
        artistTargetEl.dataset.vpArtistHint = artistName;
        artistTargetEl.dataset.vpExtraMeta = metaRaw;
        if (!artistTargetEl.dataset.vpSongInfoBound) {
          artistTargetEl.dataset.vpSongInfoBound = '1';
          artistTargetEl.addEventListener('click', function(ev) {
            ev.stopPropagation();
            var info = gatherSongInfo(
              playBox,
              artistTargetEl.dataset.vpTitleHint || '',
              artistTargetEl.dataset.vpArtistHint || '',
              artistTargetEl.dataset.vpExtraMeta || ''
            );
            openSongInfoModal(info);
          }, false);
        }
      }
    };

    var shiftPlayViewDownward = function(bottomNav) {
      var vh = window.innerHeight || 800;
      var vw = window.innerWidth || 400;
      var navTop = bottomNav.top;
      var containers = document.querySelectorAll('main, section, div');
      var deepestMatch = null;

      for (var i = 0; i < containers.length; i++) {
        var box = containers[i];
        if (box === bottomNav.el || (bottomNav.el && box.contains(bottomNav.el))) continue;
        if (!box.getBoundingClientRect) continue;
        var rect = box.getBoundingClientRect();
        if (rect.height < vh * 0.48 || rect.width < vw * 0.85) continue;
        if (rect.bottom > navTop + 16) continue;
        if (box.scrollHeight > rect.height + 64) continue;

        var buttons = box.querySelectorAll('button');
        if (buttons.length < 3 || buttons.length > 12) continue;

        var hasScrubber = box.querySelector('input[type="range"], [role="slider"], canvas');
        if (!hasScrubber) {
          var multiBars = box.querySelectorAll('div');
          for (var b = 0; b < multiBars.length; b++) {
            if (multiBars[b].children && multiBars[b].children.length >= 16) {
              var br = multiBars[b].getBoundingClientRect ? multiBars[b].getBoundingClientRect() : null;
              if (br && br.height >= 20 && br.height <= 100 && br.width >= vw * 0.6) {
                hasScrubber = multiBars[b];
                break;
              }
            }
          }
        }
        if (!hasScrubber) continue;

        var hasLargeArtwork = false;
        var artCandidates = box.querySelectorAll('img, div');
        for (var a = 0; a < artCandidates.length; a++) {
          var ar = artCandidates[a].getBoundingClientRect ? artCandidates[a].getBoundingClientRect() : null;
          if (ar && ar.width >= 130 && ar.width <= vw * 0.92 && ar.height >= 130 && ar.height <= vh * 0.48) {
            hasLargeArtwork = true;
            break;
          }
        }
        if (!hasLargeArtwork) continue;

        deepestMatch = box;
      }

      if (deepestMatch) {
        deepestMatch.classList.add('vp-play-stack-shifted');
        enhancePlayScreenMetadata(deepestMatch);
      }
    };

    var applyAll = function() {
      hideNetlifyInRoot(document);
      var bottomNav = findBottomNav();
      enhanceMiniPlayer(bottomNav);
      shiftPlayViewDownward(bottomNav);
    };

    applyAll();
    setTimeout(applyAll, 250);
    setTimeout(applyAll, 900);

    if (!window.__vaultPlayObserver) {
      var scheduled = false;
      window.__vaultPlayObserver = new MutationObserver(function() {
        if (scheduled) return;
        scheduled = true;
        requestAnimationFrame(function() {
          scheduled = false;
          applyAll();
        });
      });
      window.__vaultPlayObserver.observe(document.documentElement, {
        childList: true,
        subtree: true
      });
    }
  } catch (_) {}
})();
"""

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun VaultPlayWebView(
    isOnline: Boolean,
    savedState: Bundle?,
    commands: SharedFlow<VaultWebCommand>,
    onPageStarted: (canGoBack: Boolean) -> Unit,
    onPageVisible: () -> Unit,
    onPageFinished: (canGoBack: Boolean) -> Unit,
    onMainFrameError: (String?) -> Unit,
    onOpenExternalUri: (Uri) -> Unit,
    onBlockedNavigation: () -> Unit,
    onSaveState: (Bundle) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val currentOnPageStarted by rememberUpdatedState(onPageStarted)
    val currentOnPageVisible by rememberUpdatedState(onPageVisible)
    val currentOnPageFinished by rememberUpdatedState(onPageFinished)
    val currentOnMainFrameError by rememberUpdatedState(onMainFrameError)
    val currentOnOpenExternalUri by rememberUpdatedState(onOpenExternalUri)
    val currentOnBlockedNavigation by rememberUpdatedState(onBlockedNavigation)
    val currentOnSaveState by rememberUpdatedState(onSaveState)

    var pendingFileCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }
    val multiFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        pendingFileCallback?.onReceiveValue(
            if (uris.isEmpty()) null else uris.toTypedArray()
        )
        pendingFileCallback = null
    }
    val singleFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        pendingFileCallback?.onReceiveValue(
            if (uri == null) null else arrayOf(uri)
        )
        pendingFileCallback = null
    }

    val webView = remember {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(VAULT_PITCH_BLACK_INT)

            val currentWebView = this
            CookieManager.getInstance().apply {
                setAcceptCookie(true)
                setAcceptThirdPartyCookies(currentWebView, false)
            }

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = false
                allowContentAccess = false
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                useWideViewPort = true
                loadWithOverviewMode = true
                setSupportZoom(false)
                builtInZoomControls = false
                displayZoomControls = false
                setSupportMultipleWindows(false)
                cacheMode = if (isOnline) WebSettings.LOAD_DEFAULT else WebSettings.LOAD_CACHE_ELSE_NETWORK
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    safeBrowsingEnabled = true
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val url = request?.url?.toString()
                    val isMainFrame = request?.isForMainFrame ?: true
                    return when (val decision = UrlPolicy.evaluateNavigation(url, isMainFrame)) {
                        UrlDecision.AllowInWebView -> false
                        is UrlDecision.OpenExternally -> {
                            currentOnOpenExternalUri(Uri.parse(decision.url))
                            true
                        }
                        UrlDecision.Block -> {
                            if (isMainFrame) {
                                currentOnBlockedNavigation()
                            }
                            true
                        }
                    }
                }

                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    currentOnPageStarted(view?.canGoBack() ?: false)
                }

                override fun onPageCommitVisible(view: WebView?, url: String?) {
                    super.onPageCommitVisible(view, url)
                    view?.evaluateJavascript(VAULTPLAY_DOM_ENHANCEMENTS_JS, null)
                    currentOnPageVisible()
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(VAULTPLAY_DOM_ENHANCEMENTS_JS, null)
                    currentOnPageFinished(view?.canGoBack() ?: false)
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    super.onReceivedError(view, request, error)
                    if (request?.isForMainFrame == true) {
                        currentOnMainFrameError(error?.description?.toString())
                    }
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    pendingFileCallback?.onReceiveValue(null)
                    pendingFileCallback = filePathCallback
                    val mimeTypes = resolvePickerMimeTypes(fileChooserParams?.acceptTypes)
                    val allowMultiple =
                        fileChooserParams?.mode == FileChooserParams.MODE_OPEN_MULTIPLE
                    return runCatching {
                        if (allowMultiple) {
                            multiFilePickerLauncher.launch(mimeTypes)
                        } else {
                            singleFilePickerLauncher.launch(mimeTypes)
                        }
                        true
                    }.getOrElse {
                        pendingFileCallback?.onReceiveValue(null)
                        pendingFileCallback = null
                        false
                    }
                }
            }

            setDownloadListener { url, _, _, _, _ ->
                when (val decision = UrlPolicy.evaluateNavigation(url, isMainFrame = true)) {
                    is UrlDecision.OpenExternally -> currentOnOpenExternalUri(Uri.parse(decision.url))
                    UrlDecision.AllowInWebView -> {
                        runCatching { Uri.parse(url) }.getOrNull()?.let(currentOnOpenExternalUri)
                    }
                    UrlDecision.Block -> currentOnBlockedNavigation()
                }
            }

            val restored = savedState?.let { restoreState(it) }
            if (restored == null && UrlPolicy.isSafeInitialUrl(UrlPolicy.PRIMARY_URL)) {
                loadUrl(UrlPolicy.PRIMARY_URL)
            }
        }
    }

    LaunchedEffect(commands, webView) {
        commands.collect { command ->
            when (command) {
                VaultWebCommand.GoBack -> if (webView.canGoBack()) webView.goBack()
                VaultWebCommand.Reload -> webView.reload()
            }
        }
    }

    DisposableEffect(lifecycleOwner, webView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> webView.onResume()
                Lifecycle.Event.ON_PAUSE -> webView.onPause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            val bundle = Bundle()
            webView.saveState(bundle)
            currentOnSaveState(bundle)
            pendingFileCallback?.onReceiveValue(null)
            pendingFileCallback = null
            webView.destroy()
        }
    }

    AndroidView(
        factory = { webView },
        update = { view ->
            view.settings.cacheMode =
                if (isOnline) WebSettings.LOAD_DEFAULT else WebSettings.LOAD_CACHE_ELSE_NETWORK
        },
        modifier = modifier.testTag("vaultplay_webview")
    )
}

private fun resolvePickerMimeTypes(acceptTypes: Array<String>?): Array<String> {
    if (acceptTypes.isNullOrEmpty()) return arrayOf("audio/*", "*/*")
    val mapped = acceptTypes
        .flatMap { it.split(",") }
        .map { it.trim().lowercase() }
        .filter { it.isNotBlank() }
        .mapNotNull { token ->
            when {
                token.contains("/") -> token
                token in setOf(".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".opus", ".webm") -> "audio/*"
                token in setOf(".jpg", ".jpeg", ".png", ".webp", ".gif") -> "image/*"
                else -> null
            }
        }
        .distinct()
    return if (mapped.isEmpty()) arrayOf("audio/*", "*/*") else mapped.toTypedArray()
}
