package com.example.ui

import android.app.Application
import android.os.Bundle
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.NetworkMonitor
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class VaultPlayUiState(
    val isInitialLoading: Boolean = true,
    val canGoBack: Boolean = false,
    val isOnline: Boolean = true,
    val hasError: Boolean = false,
    val errorDescription: String? = null
)

sealed interface VaultWebCommand {
    data object GoBack : VaultWebCommand
    data object Reload : VaultWebCommand
}

class VaultPlayViewModel(
    application: Application,
    private val networkMonitor: NetworkMonitor
) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(VaultPlayUiState())
    val uiState: StateFlow<VaultPlayUiState> = _uiState.asStateFlow()

    private val _commands = MutableSharedFlow<VaultWebCommand>(extraBufferCapacity = 16)
    val commands: SharedFlow<VaultWebCommand> = _commands.asSharedFlow()

    var savedWebViewState: Bundle? = null
        private set

    init {
        viewModelScope.launch {
            networkMonitor.isOnline.collect { online ->
                val wasOfflineWithError = !_uiState.value.isOnline && _uiState.value.hasError
                _uiState.update { it.copy(isOnline = online) }
                if (online && wasOfflineWithError) {
                    reload()
                }
            }
        }
    }

    fun onPageStarted(canGoBack: Boolean) {
        _uiState.update {
            it.copy(
                hasError = false,
                errorDescription = null,
                canGoBack = canGoBack
            )
        }
    }

    fun onPageVisible() {
        _uiState.update { it.copy(isInitialLoading = false) }
    }

    fun onPageFinished(canGoBack: Boolean) {
        _uiState.update {
            it.copy(
                isInitialLoading = false,
                canGoBack = canGoBack
            )
        }
    }

    fun onMainFrameError(description: String?) {
        _uiState.update {
            it.copy(
                isInitialLoading = false,
                hasError = true,
                errorDescription = description?.takeIf { d -> d.isNotBlank() }
            )
        }
    }

    fun goBack() {
        _commands.tryEmit(VaultWebCommand.GoBack)
    }

    fun reload() {
        _uiState.update {
            it.copy(
                hasError = false,
                errorDescription = null,
                isInitialLoading = true
            )
        }
        _commands.tryEmit(VaultWebCommand.Reload)
    }

    fun saveWebViewBundle(bundle: Bundle) {
        savedWebViewState = bundle
    }

    override fun onCleared() {
        super.onCleared()
        networkMonitor.unregister()
    }

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return VaultPlayViewModel(
                application = application,
                networkMonitor = NetworkMonitor(application)
            ) as T
        }
    }
}
