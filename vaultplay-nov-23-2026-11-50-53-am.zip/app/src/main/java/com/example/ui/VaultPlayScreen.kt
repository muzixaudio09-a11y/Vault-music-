package com.example.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.VaultPlayWebView
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.FrostedDarkGlass
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.PitchBlack
import kotlinx.coroutines.launch

@Composable
fun VaultPlayScreen(
    viewModel: VaultPlayViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    BackHandler(enabled = uiState.canGoBack) {
        viewModel.goBack()
    }

    val openExternalUri: (Uri) -> Unit = { uri ->
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            addCategory(Intent.CATEGORY_BROWSABLE)
        }
        runCatching {
            context.startActivity(intent)
        }.onFailure {
            coroutineScope.launch {
                snackbarHostState.showSnackbar(
                    context.getString(R.string.msg_external_browser_error)
                )
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = PitchBlack,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier.windowInsetsPadding(WindowInsets.safeDrawing)
            )
        }
    ) { _ ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(PitchBlack)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .imePadding()
        ) {
            VaultPlayWebView(
                isOnline = uiState.isOnline,
                savedState = viewModel.savedWebViewState,
                commands = viewModel.commands,
                onPageStarted = viewModel::onPageStarted,
                onPageVisible = viewModel::onPageVisible,
                onPageFinished = viewModel::onPageFinished,
                onMainFrameError = viewModel::onMainFrameError,
                onOpenExternalUri = openExternalUri,
                onBlockedNavigation = {
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar(
                            context.getString(R.string.msg_blocked_scheme)
                        )
                    }
                },
                onSaveState = viewModel::saveWebViewBundle,
                modifier = Modifier.fillMaxSize()
            )

            AnimatedVisibility(
                visible = uiState.isInitialLoading && !uiState.hasError,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(PitchBlack),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.GraphicEq,
                            contentDescription = null,
                            tint = NeonGreen,
                            modifier = Modifier.size(44.dp)
                        )
                        CircularProgressIndicator(
                            color = NeonGreen,
                            trackColor = FrostedDarkGlass,
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }
            }

            if (uiState.hasError) {
                VaultPlayErrorOverlay(
                    isOnline = uiState.isOnline,
                    errorDescription = uiState.errorDescription,
                    onRetry = viewModel::reload
                )
            }
        }
    }
}

@Composable
private fun VaultPlayErrorOverlay(
    isOnline: Boolean,
    errorDescription: String?,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(PitchBlack)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = FrostedDarkGlass,
            border = BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.28f)),
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 420.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.WifiOff,
                    contentDescription = null,
                    tint = NeonGreen,
                    modifier = Modifier.size(36.dp)
                )

                Text(
                    text = stringResource(if (!isOnline) R.string.offline_title else R.string.error_title),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = stringResource(if (!isOnline) R.string.offline_subtitle else R.string.error_subtitle),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                if (!errorDescription.isNullOrBlank() && isOnline) {
                    Text(
                        text = errorDescription,
                        style = MaterialTheme.typography.labelSmall,
                        color = EmeraldGreen,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = onRetry,
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonGreen,
                        contentColor = PitchBlack
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("retry_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.action_retry),
                        style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}
