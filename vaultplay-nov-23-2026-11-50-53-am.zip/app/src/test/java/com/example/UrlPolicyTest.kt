package com.example

import com.example.util.UrlDecision
import com.example.util.UrlPolicy
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class UrlPolicyTest {

    @Test
    fun primaryNetlifyHttpsUrl_isAllowedInWebView() {
        val decision = UrlPolicy.evaluateNavigation(
            rawUrl = "https://moonlit-trifle-74edc5.netlify.app/dashboard?tab=1",
            isMainFrame = true
        )
        assertEquals(UrlDecision.AllowInWebView, decision)
        assertTrue(UrlPolicy.isSafeInitialUrl(UrlPolicy.PRIMARY_URL))
    }

    @Test
    fun externalHttpsUrl_opensExternallyOnMainFrame() {
        val decision = UrlPolicy.evaluateNavigation(
            rawUrl = "https://example.com/docs",
            isMainFrame = true
        )
        assertEquals(UrlDecision.OpenExternally("https://example.com/docs"), decision)
    }

    @Test
    fun mailtoAndTel_openExternallyOnMainFrame() {
        assertEquals(
            UrlDecision.OpenExternally("mailto:hello@example.com"),
            UrlPolicy.evaluateNavigation("mailto:hello@example.com", isMainFrame = true)
        )
        assertEquals(
            UrlDecision.OpenExternally("tel:+15551234567"),
            UrlPolicy.evaluateNavigation("tel:+15551234567", isMainFrame = true)
        )
    }

    @Test
    fun unsafeSchemes_areBlocked() {
        assertEquals(
            UrlDecision.Block,
            UrlPolicy.evaluateNavigation("javascript:alert(1)", isMainFrame = true)
        )
        assertEquals(
            UrlDecision.Block,
            UrlPolicy.evaluateNavigation("file:///etc/passwd", isMainFrame = true)
        )
        assertEquals(
            UrlDecision.Block,
            UrlPolicy.evaluateNavigation("intent://scan/#Intent;end", isMainFrame = true)
        )
        assertFalse(UrlPolicy.isHttpsUrl("http://moonlit-trifle-74edc5.netlify.app"))
    }
}
